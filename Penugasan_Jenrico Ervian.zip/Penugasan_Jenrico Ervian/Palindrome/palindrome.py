def palindrome(s):
    sr=s[::-1]
    if s==sr:
        return True
    else:
        return False
while True:
    s=input("Enter a string (quit to exit) : ")
    if s=="quit":
        ("See you later!!")
        break
    if palindrome(s)==True:
        print("This is palindrome")
    else:
        print("This is not Palindrome")